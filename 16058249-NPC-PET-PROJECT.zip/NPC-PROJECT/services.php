
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="./NPCdatabasewebsite/style.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
    <title>Noah's pet clinic</title>
</head>
<body>
<!--NAVBAR-->
<nav class="navbar navbar-expand-lg navbar-light bg-light  ">
        <a class="navbar-brand" href="#"> <img src="./NPCdatabasewebsite/images/npclogo.png" width="150" height="65" alt=""></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav mx-auto">
            <li class="nav-item ">
              <a class="nav-link" href="index.html">Home</a>
            </li>
            <li class="nav-item active">
              <a class="nav-link" href="../services.php">Services</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="aboutus.html">About us</a>
            </li>
            
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                Pet advice
              </a>
              <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                <a class="dropdown-item" href="#">Cats and Dogs</a>
                <a class="dropdown-item" href="#">Rabbits and Hamsters</a>
                <a class="dropdown-item" href="#">Other Pets</a>
              </div>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="getintouch.html">Get in touch</a>
            </li>
          </ul>
        </div>
	  </nav>
	  
<section id="services-heading">
	<div class="row">
		<div class="col">
				<div class="container">
				<h1 class="display-4 text-center">Services</h1>
				<p class="lead">Our devoted team of specalist vet doctor and nurses, work day five days aweek to provide all our customers with the services. Sometimes our customers prefer to know the approximate prices or our appointments, please enter you pets age below and see the estimated prices. It is our belief that all pets of any age should be treated no matter the illness, but to keep our joy of treating pets we as a clinic beleve costs should be kept low. This is why new born pets are charged the same amount as age 1 pets and we dont accept pets over the age of 12.</p>
				</div>
		</div>
	</div>
</section>


<!--PRICE FORM SECTION-->
<section id="price-form"> 
<!--FORM-->
<form method='GET' class="text-center" action='services.php'>
<label for="petage">Petage(£):</label>
<input type="text"  name='yyy' />
<input type='submit' value='price'>

</form>
<!--FORM PHP-->
<?php
$con = mysqli_connect("localhost","root","", "petageprices");
	if (!$con) {
		die ("Failed");
	}
	// echo "success.";

	$a = $_GET['yyy'];

	
$sql = "SELECT * FROM petageprices where petage='$a' ";
	$result = $con->query($sql);
	if ($result->num_rows > 0) { 
		while($row = $result->fetch_assoc()) {  
			echo ("price:".$row["price"]."<br>"); 
		} 
	}
    else {
		echo "no such service"; 
	} 
	?>
</section>
<!--PACKAGES-->
<section id="packages">
	<div class="row">
		<div class="col">
			<div class="container">
				<h1 class="display-4 text-center">Packages</h1>
				<div class="card-deck">
<!--CARD 1-->
				<div class="card">
  <img src="./NPCdatabasewebsite/images/vetservices-1.jpg" class="card-img-top" alt="vet checking dogs ear">
  <div class="card-body">
    <p class="card-text">Pet Health Checks</p>
    <p>A top of the line health check which will cover all the bases of pet to make we are top of everything and watch out for any problems with your pets.</p>
    <a href="#" class="btn btn-primary">Click here to book your health check</a>
  </div>
</div>
<!--CARD 2-->
  <div class="card">
  <img src="./NPCdatabasewebsite/images/vetservices-2.jpg" class="card-img-top" alt="cat being treated">
  <div class="card-body">
    <p class="card-text">Pet Vacinations</p>
    <p> A full health check by our professional will be done before any vaccinations are done to make sure your pet has no adverse reaction to any of our approved vacinations </p>
    <a href="#" class="btn btn-primary">Click here to book Pets Vacination</a>
  </div>
</div>
<!--CARD 3-->
<div class="card">
  <img src="./NPCdatabasewebsite/images/vetservices-3.jpg" class="card-img-top" alt="cat getting nails cut">
  <div class="card-body">
    <p class="card-text">Pet neutering Services</p>
    <p> A simple procedure that will save you money in the future. Our top of the line Pet neutering Services will have your pet back in no time, just drop them off and they will be back to you on the same day.</p>
    <a href="#" class="btn btn-primary">Book your pet neutering service</a>
  </div>
</div>
			</div>
		</div>
	</div>
</section>


<!--MAIN FOOTER-->
<footer id="footer">
        <div class="row">
          <div class="col">
            <div class="container text-center">
              <p> &#169; Noah's pet clinic 2020.</p>
            </div>
          </div>
        </div>
      </footer>





<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>
</body>
</html>